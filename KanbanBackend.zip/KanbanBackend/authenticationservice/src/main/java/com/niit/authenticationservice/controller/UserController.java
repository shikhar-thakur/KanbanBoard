package com.niit.authenticationservice.controller;
import com.niit.authenticationservice.security.JwtSecurityToken;
import com.niit.authenticationservice.model.User;
import com.niit.authenticationservice.service.UserServiceImpl;
import com.niit.authenticationservice.exception.UserAlreadyExistException;
import com.niit.authenticationservice.exception.UserNotExistException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v2")
@CrossOrigin("http://localhost:4200")
public class UserController{
UserServiceImpl userService;
JwtSecurityToken securityToken;


@Autowired
    public UserController(UserServiceImpl userService,JwtSecurityToken securityToken)
{
    this.userService = userService;
    this.securityToken = securityToken;

}
@PostMapping("/register")

    public ResponseEntity<?>addingUserData(@RequestBody User user)throws UserAlreadyExistException{
    try{
        return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);

    }
    catch (UserAlreadyExistException e){
        throw new UserAlreadyExistException();
    }
catch(Exception e){
    System.out.println(e.toString()+"authorization service error");;
    return new ResponseEntity<>("please try after sometimes",HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

@PostMapping("/login")
    public ResponseEntity<?>findByUserEmailandPassword( @RequestBody User user) throws UserNotExistException{
        Map<String,String> map=null;
        try{
            User user1 = userService.loginUser(user.getEmail(),user.getPassword());
            if(user1!=null){
                map=securityToken.createUserToken(user);
            }
            return new ResponseEntity<>(map,HttpStatus.OK);
        }
        catch(UserNotExistException ex){
            throw new UserNotExistException();
        }
        catch(Exception ex){
            return new ResponseEntity<>("Please Try After Sometimes",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PostMapping("/update/{emailId}")
    public ResponseEntity<?> updateUser(@PathVariable String emailId, @RequestBody User user) throws UserNotExistException {
        try {
            return new ResponseEntity<>(userService.updateUserDate(emailId,user), HttpStatus.CREATED);
        }
        catch (UserNotExistException ex){
            throw new UserNotExistException();
        }catch (Exception e) {
            return new ResponseEntity<>("please try after some times",HttpStatus.CONFLICT);
        }
    }
}