package com.niit.authenticationservice.service;

import com.niit.authenticationservice.exception.UserAlreadyExistException;
import com.niit.authenticationservice.exception.UserNotExistException;
import com.niit.authenticationservice.model.User;
import com.niit.authenticationservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private UserRepository userRepository;
    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) throws UserAlreadyExistException {
        if (userRepository.findById(user.getEmail()).isPresent()){
            throw new UserAlreadyExistException();
        }
        return userRepository.save(user);
    }

    @Override
    public User loginUser(String emailId,String password) throws  UserNotExistException {
       User user= userRepository.findByEmailAndPassword(emailId,password);
        if (user==null){
            throw new UserNotExistException();
        }
        return user;
    }

    @Override
    public User updateUserDate(String email,User user1) throws UserNotExistException {
        if (userRepository.findById(email).isEmpty()){
            throw new UserNotExistException();
        }
        User user =userRepository.findById(email).get();
        user.setPassword(user1.getPassword());
        userRepository.save(user);
        return user;
    }

    @Override
    public boolean deleteUserData(String email){
        return userRepository.deleteByEmail(email);
    }
}
