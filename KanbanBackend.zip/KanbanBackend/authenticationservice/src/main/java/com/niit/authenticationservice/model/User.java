package com.niit.authenticationservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//DEVELOPED TO Group 2- KANBAN-BOARD APPLICATION [AMAN MASIH, SHEKHAR LOBO,SAI SANJANA BHUPATHIRAJU]
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    private  String email;
    private String password;
    private String username;
}
