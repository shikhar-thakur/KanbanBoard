//package com.kanban.kanbanTask.service;
//import com.kanban.kanbanTask.config.ProducerTask;
//import com.kanban.kanbanTask.controller.UserController;
//import com.kanban.kanbanTask.exception.TaskNotExistException;
//import com.kanban.kanbanTask.model.Task;
//import com.kanban.kanbanTask.model.User;
//import com.kanban.kanbanTask.rabbitMQ.TaskDTO;
//import com.kanban.kanbanTask.rabbitMQ.UserDTO;
//import com.kanban.kanbanTask.repository.TaskRepository;
//
//import org.junit.jupiter.api.*;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//
//import java.time.LocalDate;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class TaskServiceTest {
//
//    @InjectMocks
//    private TaskServiceImpl taskService;
//
//
//    @Mock
//    private TaskRepository taskRepository;
//
//    private User user;
//    private Task task;
//    private List<Task> taskList;
//    private ProducerTask producerTask;
//
//    @BeforeEach
//    public void setUp() throws ParseException {
//        //Disclaimer :- before running test cases make sure you have this user in your MongoDb database because it is used for the position of assignee(User), and here we are not registering any user Explicitly from Task Service so please check it once
//        user = new User("xyz@gmail.com","123456","xyz");
//        String testDate = "29-Mar-2022,13:00:14 PM";
//        DateFormat formatter = new SimpleDateFormat("d-MMM-yyyy,hh:mm:ss aaa");
//        Date date = formatter.parse(testDate);
//        System.out.println(date);
//        task = new Task(99,"task99","testing task for kanaban - I",date,user,"pending");
//    }
//
//    @AfterEach
//    public void tearDown(){
//        user=null;
//        task=null;
//        taskRepository.deleteAll();
//        taskList = null;
//    }
//
////    //this might fail because of RabbitMQ interception
////    @Test
////    public void givenTaskAddSuccessful(){
////        when(taskRepository.findById(task.getTaskId())).thenReturn(Optional.ofNullable(null));
////        when(taskRepository.save(task)).thenReturn(task);
//////        UserDTO userDTO =  new UserDTO(task.getTaskAssignee().getEmail(),task.getTaskAssignee().getPassword(),task.getTaskAssignee().getUserName());
//////        TaskDTO taskDTO =  new TaskDTO(task.getTaskId(),task.getTaskTitle(), task.getTaskDescription(), task.getTaskDeadLine(),userDTO,task.getTaskStatus());
////        assertEquals(task,taskService.addTask(task));
////        verify(taskRepository,times(1)).findById(task.getTaskId());
////    }
//
//
//    @Test
//    public void givetaskDeletefailure(){
//        when(taskRepository.findById(task.getTaskId())).thenReturn(Optional.ofNullable(null));
//        assertThrows(TaskNotExistException.class,()->taskService.deleteTask(task.getTaskId()));
//        verify(taskRepository,times(1)).findById(task.getTaskId());
//        verify(taskRepository,times(0)).deleteById(task.getTaskId());
//    }
//
//    @Test
//    public void givenTaskUpdateFailure(){
//        when(taskRepository.findById(task.getTaskId())).thenReturn(Optional.ofNullable(null));
//        assertThrows(TaskNotExistException.class,()->taskService.updateTask(task));
//        verify(taskRepository,times(1)).findById(task.getTaskId());
//        verify(taskRepository,times(0)).save(task);
//
//    }
//
//    //negative testcases for task
//    @Test
//    public void getTaskTitleFailure() throws Exception {
//        when(taskRepository.findByTaskTitle(task.getTaskTitle())).thenReturn(task);
//        assertNotEquals(null,taskService.searchTask("task99"));
//        verify(taskRepository,times(1)).findByTaskTitle("task99");
//    }
//
//    @Test
//    public void searchTaskSuccess(){
//        when(taskRepository.findByTaskTitle(task.getTaskTitle())).thenReturn(task);
//        assertEquals(task,taskService.searchTask("task99"));
//        verify(taskRepository,times(1)).findByTaskTitle("task99");
//    }
////
////    @Test
////    public void deadlineAlertFailure(){
////        assertEquals("Red",()->taskService.deadlineAlert(task.getTaskDeadLine(Date("2022-03-29"))));
////    }
//}//end of class
