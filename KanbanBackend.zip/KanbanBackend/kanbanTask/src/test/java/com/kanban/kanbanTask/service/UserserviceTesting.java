///package com.kanban.kanbanTask.service;
//import com.kanban.kanbanTask.exception.UserExistException;

//import com.kanban.kanbanTask.exception.UserNotExistException;
//import com.kanban.kanbanTask.model.User;
//import com.kanban.kanbanTask.repository.UserRepository;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//@ExtendWith({MockitoExtension.class})
//public class UserserviceTesting {
//    @Mock
//    private UserRepository userRepository;
//
//    @InjectMocks
//    private UserServiceImpl userService;
//
//    private User user1;
//    private List<User> userList;
//
//    @BeforeEach
//    public void setUp(){
//        user1=new User("Sanju1@gmail.com","sanju123","17");
//        userList= Arrays.asList(user1);
//    }
//    @AfterEach
//    public void tearDown () {
//        user1 = null;
//    }
//    @Test
//    public void givenUserToAddReturnUserSuccess() throws UserExistException {
//        when(userRepository.findById(user1.getEmail())).thenReturn(Optional.ofNullable(null));
//        when(userService.addUser(user1)).thenReturn(user1);
//        assertEquals(user1,userService.addUser(user1));
//        verify(userRepository,times(2)).findById(user1.getEmail());
//        verify(userRepository,times(1)).save(user1);
//    }
//    @Test
//    public void givenUserToAddReturnUserFailure() {
//        when(userRepository.findById(user1.getEmail())).thenReturn(Optional.ofNullable(user1));
//        assertThrows(UserExistException.class,()->userService.addUser(user1));
//        verify(userRepository,times(1)).findById(user1.getEmail());
//        verify(userRepository,times(0)).save(user1);
//    }
//    @Test
//    public void updateUserSuccess() throws UserNotExistException {
//        User userTemp = new User("Sanju1@gmail.com","sanju123","sanjana");
//     when(userRepository.findByEmail(user1.getEmail())).thenReturn(Optional.ofNullable(user1).get());
//    user1.setUserName("sanjana");
//    assertEquals(userTemp,userService.updateUser("Sanju1@gmail.com",user1));
//    verify(userRepository,times(1)).findByEmail(user1.getEmail());
//    userTemp = null;
//    }
//    @Test
//    public void getUserTestingSuccess() throws UserNotExistException {
//    when(userRepository.findAll()).thenReturn(Optional.ofNullable(userList).get());
//    assertEquals(userList,userService.getUsers());
//    }
//}//end of class





































// DEVELOPED By Group 2(Wave-16)- KANBAN-BOARD APPLICATION [AMAN MASIH, SHEKHAR LOBO,SAI SANJANA BHUPATHIRAJU]