package com.kanban.kanbanTask.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code= HttpStatus.NOT_FOUND, reason="Team does not found")
public class TeamNotExistException extends Exception {
}
