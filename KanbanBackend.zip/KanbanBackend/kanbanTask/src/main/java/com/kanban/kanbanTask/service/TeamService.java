package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.TaskNotExistException;
import com.kanban.kanbanTask.exception.TeamAlreadyExistException;
import com.kanban.kanbanTask.exception.TeamNotExistException;
import com.kanban.kanbanTask.exception.UserNotExistException;
import com.kanban.kanbanTask.model.Task;
import com.kanban.kanbanTask.model.Team;
import com.kanban.kanbanTask.model.User;

import java.util.List;

public interface TeamService {
    Team addTeam(Team team) throws TeamAlreadyExistException;
    boolean deleteTeam(String teamName) throws TeamNotExistException;
    Team updateTeam(Team team) throws TeamNotExistException;

    Task addtaskToTeam(String teamName,String taskTitle)throws TaskNotExistException,TeamNotExistException;

    User addTeamMember(String teamName,String email)throws UserNotExistException,TeamNotExistException;

    List<Team>getAllTeams();

    List<User>getAllTeamMembers(String teamName)throws TeamNotExistException;

    List<Task>getAllTeamTasks(String teamName) throws TeamNotExistException;

}
