package com.kanban.kanbanTask.repository;

import com.kanban.kanbanTask.model.User;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
    boolean deleteByEmail(String email);
    User findByEmail(String email);
}
