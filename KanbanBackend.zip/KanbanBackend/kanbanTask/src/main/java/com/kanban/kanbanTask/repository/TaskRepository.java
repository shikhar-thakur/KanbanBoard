package com.kanban.kanbanTask.repository;

import com.kanban.kanbanTask.model.Task;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskRepository extends MongoRepository<Task, Long> {
    Task findByTaskTitle(String taskTitle);
    List<Task> findByTaskAssignee_Email(String email);
    Task findByTaskId(long id);
    boolean deleteByTaskId(long id);
    Task findByTaskTitleAndTaskAssignee_Email(String taskTitle,String Assignee);

}


























































































