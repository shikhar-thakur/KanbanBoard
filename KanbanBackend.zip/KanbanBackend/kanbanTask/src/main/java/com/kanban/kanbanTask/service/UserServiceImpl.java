package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.UserExistException;
import com.kanban.kanbanTask.exception.UserNotExistException;
import com.kanban.kanbanTask.model.User;
import com.kanban.kanbanTask.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{
    private UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User addUser(User user) throws UserExistException {
        if(userRepository.findById(user.getEmail())==null){
            throw new UserExistException();
        }
        return userRepository.save(user);
    }

    @Override
    public User updateUser(String email, User user) throws UserNotExistException {
        if (userRepository.findByEmail(email)==null){
            throw new UserNotExistException();
        }
        User u =userRepository.findByEmail(email);
        u.setPassword(user.getPassword());
        u.setUserName(user.getUserName());
        userRepository.save(u);
        return u;
    }

    @Override
    public User getUser(String email) throws UserNotExistException {
        User u=userRepository.findByEmail(email);
        if(u==null){
            throw new UserNotExistException();
        }
        return u;
    }

    @Override
    public List<User> getUsers(){
        return userRepository.findAll();
    }
}





















































