package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.UserExistException;
import com.kanban.kanbanTask.exception.UserNotExistException;
import com.kanban.kanbanTask.model.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    User addUser(User user) throws UserExistException;
    User updateUser(String email, User user) throws UserNotExistException;
    User getUser(String email) throws UserNotExistException;
    List<User> getUsers();
}




















































































// DEVELOPED By Group 2(Wave-16)- KANBAN-BOARD APPLICATION [AMAN MASIH, SHEKHAR LOBO,SAI SANJANA BHUPATHIRAJU]
