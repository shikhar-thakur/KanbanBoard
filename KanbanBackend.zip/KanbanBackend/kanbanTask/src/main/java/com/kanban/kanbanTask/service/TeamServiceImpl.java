package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.TaskNotExistException;
import com.kanban.kanbanTask.exception.TeamAlreadyExistException;
import com.kanban.kanbanTask.exception.TeamNotExistException;
import com.kanban.kanbanTask.exception.UserNotExistException;
import com.kanban.kanbanTask.model.Task;
import com.kanban.kanbanTask.model.Team;
import com.kanban.kanbanTask.model.User;
import com.kanban.kanbanTask.repository.TaskRepository;
import com.kanban.kanbanTask.repository.TeamRepository;
import com.kanban.kanbanTask.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class TeamServiceImpl implements TeamService{
    TeamRepository teamRepository;
    TaskRepository taskRepository;
    UserRepository userRepository;

    @Autowired
    public TeamServiceImpl(TeamRepository teamRepository, TaskRepository taskRepository, UserRepository userRepository) {
        this.teamRepository = teamRepository;
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    @Override
    public Team addTeam(Team team) throws TeamAlreadyExistException{
        if(teamRepository.findById(team.getTeamName()).isPresent()){
            throw new TeamAlreadyExistException();
        }
        return teamRepository.save(team);
    }

    @Override
    public boolean deleteTeam(String teamName) throws TeamNotExistException {
        boolean result =false;
        if(teamRepository.findById(teamName).isPresent()){
            teamRepository.deleteById(teamName);
            result = true;
        }
        else if(teamRepository.findById(teamName).isEmpty()){throw new TeamNotExistException();}
        return result;
    }

    @Override
    public Team updateTeam(Team team)throws TeamNotExistException{
        if(teamRepository.findById(team.getTeamName()).isEmpty()){
            throw new TeamNotExistException();
        }
        return teamRepository.save(team);
    }

    @Override
    public Task addtaskToTeam(String teamName, String taskTitle) throws TaskNotExistException, TeamNotExistException {
        if(teamRepository.findById(teamName).isEmpty()){throw new TeamNotExistException();}
        else if(taskRepository.findById(taskRepository.findByTaskTitle(taskTitle).getTaskId()).isEmpty()){throw new TaskNotExistException(); }

        else{
            long tempTask = taskRepository.findByTaskTitle(taskTitle).getTaskId();
            Team temp = teamRepository.findById(teamName).get();

            if(teamRepository.findById(teamName).get().getTeamTasks() == null){
                temp.setTeamTasks(Arrays.asList(taskRepository.findById(tempTask).get()));
            }
            else{
                List<Task>teamList =  teamRepository.findById(teamName).get().getTeamTasks();
                teamList.add(taskRepository.findById(tempTask).get());
            }
            teamRepository.save(temp);
        }
        return taskRepository.findById(taskRepository.findByTaskTitle(taskTitle).getTaskId()).get();
    }

    @Override
    public User addTeamMember(String teamName, String email) throws UserNotExistException, TeamNotExistException {
        if(teamRepository.findById(teamName).isEmpty()){throw new TeamNotExistException();}
        else if(userRepository.findById(email).isEmpty()){throw new UserNotExistException(); }

        else{
            Team temp = teamRepository.findById(teamName).get();

            if(teamRepository.findById(teamName).get().getTeamMembers() == null){
                temp.setTeamMembers(Arrays.asList(userRepository.findById(email).get()));
            }
            else{
                List<User> userList =  teamRepository.findById(teamName).get().getTeamMembers();
                userList.add(userRepository.findById(email).get());
            }
            teamRepository.save(temp);
        }
        return userRepository.findById(email).get();
    }

    @Override
    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    @Override
    public List<User> getAllTeamMembers(String teamName) throws TeamNotExistException {
        if(teamRepository.findById(teamName).isEmpty()){throw new TeamNotExistException();}
        return teamRepository.findByTeamMembers(teamName);
    }

    @Override
    public List<Task> getAllTeamTasks(String teamName) throws TeamNotExistException {
        if(teamRepository.findById(teamName).isEmpty()){throw new TeamNotExistException();}
        return teamRepository.findByTeamTasks(teamName);
    }

}
