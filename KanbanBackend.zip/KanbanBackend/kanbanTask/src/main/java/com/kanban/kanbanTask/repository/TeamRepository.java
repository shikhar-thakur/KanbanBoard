package com.kanban.kanbanTask.repository;
import com.kanban.kanbanTask.model.Task;
import com.kanban.kanbanTask.model.Team;
import com.kanban.kanbanTask.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TeamRepository extends MongoRepository<Team,String>{
    List<Task> findByTeamTasks(String teamName);
    List<User>findByTeamMembers(String teamName);

}
