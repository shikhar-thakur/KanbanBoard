package com.kanban.kanbanTask.controller;

import com.kanban.kanbanTask.exception.TaskNotExistException;
import com.kanban.kanbanTask.exception.UserExistException;
import com.kanban.kanbanTask.exception.UserNotExistException;
import com.kanban.kanbanTask.model.Task;
import com.kanban.kanbanTask.model.Team;
import com.kanban.kanbanTask.model.User;
import com.kanban.kanbanTask.proxy.UserProxy;
import com.kanban.kanbanTask.repository.TaskRepository;
import com.kanban.kanbanTask.service.TaskService;
import com.kanban.kanbanTask.service.TeamService;
import com.kanban.kanbanTask.service.UserService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api")
public class UserController {
    private UserService userService;
    private TaskService taskService;
    private TeamService teamService;
    private UserProxy userProxy;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    public UserController(UserService userService, TaskService taskService,  TeamService teamService, UserProxy userProxy) {
        this.userService = userService;
        this.taskService = taskService;
        this.teamService = teamService;
        this.userProxy = userProxy;
    }

    @PostMapping("/user/add")
    public ResponseEntity<?> addUser(@RequestBody User user) throws UserExistException {
        try {
            userProxy.addingUserData(user);
            return new ResponseEntity<>(userService.addUser(user), HttpStatus.CREATED);
        } catch (UserExistException ue) {
            throw new UserExistException();
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @CrossOrigin("http://localhost:4200")
    @PutMapping("/user/update/{email}")
    public ResponseEntity<?> updateUser(@PathVariable String email, @RequestBody User user) throws UserNotExistException {
        try {
            userProxy.updateUser(email,user);
            return new ResponseEntity<>(userService.updateUser(email, user), HttpStatus.OK);
        } catch (UserNotExistException une) {
            throw new UserNotExistException();
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/user/getall")
    public ResponseEntity<?> getUser() {
        return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);
    }

    @GetMapping("/user/get/{email}")
    public ResponseEntity<?> getUser(@PathVariable String email) throws UserNotExistException {
        return new ResponseEntity<>(userService.getUser(email), HttpStatus.OK);
    }
  //tasks
    @PostMapping("/task/add")
    public ResponseEntity<?> addTask(@RequestBody Task task) {
        try {
            return new ResponseEntity<>(taskService.addTask(task), HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


@CrossOrigin("http://localhost:4200")
@PostMapping("/task/update")
    public ResponseEntity<?> updateTask(@RequestBody Task task) throws TaskNotExistException {
        try {
            return new ResponseEntity<>(taskService.updateTask(task), HttpStatus.OK);
        } catch (TaskNotExistException une) {
            throw new TaskNotExistException();
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/task/delete/{taskId}")
    public ResponseEntity<?> deleteTask(@PathVariable int taskId) throws TaskNotExistException {
        try {
            return new ResponseEntity<>(taskService.deleteTask(taskId), HttpStatus.OK);
        } catch (TaskNotExistException une) {
            throw new TaskNotExistException();
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/task/deadline/{taskDead}")
    public ResponseEntity<?> deadlineAlert(@PathVariable LocalDate taskDead) {
        try {
            return new ResponseEntity<>(taskService.deadlineAlert(taskDead), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/task/search/{title}")
    public ResponseEntity<?> searchTask(@PathVariable String title) {
        try {
            return new ResponseEntity<>(taskService.searchTask(title), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/task/searchtaskbyuser/{taskTitle}/{taskAssignee}")
    public ResponseEntity<?> searchTaskbyUser(@PathVariable String taskTitle,@PathVariable String taskAssignee) {
        try {
            return new ResponseEntity<>(taskService.findByTaskTitleAndTaskAssignee(taskTitle,taskAssignee), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/task/getAll/{email}")
    public ResponseEntity<?> getAllTask(@PathVariable String email) {
        try {
            return new ResponseEntity<>(taskService.getAllTasks(email), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("try after some time", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("task/getdeadline/{date}")
    public ResponseEntity<?>getcolor(@PathVariable String date){
        try{
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.parse(date, formatter);
            return new ResponseEntity<>(taskService.deadlineAlert(localDate),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try again after some time",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //teams
    @PostMapping("task/team/addteam")
    public ResponseEntity<?> addTeam(@RequestBody Team team){
        try{
            return new ResponseEntity<>(teamService.addTeam(team),HttpStatus.CREATED);
        }
        catch(Exception e){return new ResponseEntity<>("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);}
    }

    @DeleteMapping("task/team/deleteteam/{teamName}")
    public ResponseEntity<?>deleteTeam(@PathVariable String teamName){
        try{
            return new ResponseEntity<>(teamService.deleteTeam(teamName),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("task/team/updateteam")
    public ResponseEntity<?>updateTeam(@RequestBody Team team){
        try{
            return new ResponseEntity<>(teamService.updateTeam(team),HttpStatus.OK);
        }
        catch(Exception e){return new ResponseEntity<>("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);}
    }

    @PostMapping("task/team/addtasktoteam/{teamName}/{taskTitle}")
    public ResponseEntity<?>addTaskToTeam(@PathVariable String teamName,@PathVariable String taskTitle){
        try{
            return new ResponseEntity<>(teamService.addtaskToTeam(teamName,taskTitle),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try after some time",HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("task/team/addmembertoteam/{teamName}/{email}")
    public ResponseEntity<?>addMemberToTeam(@PathVariable String teamName,@PathVariable String email){
        try{
            return new ResponseEntity<>(teamService.addTeamMember(teamName,email),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try after some time",HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("task/team/getallteam")
    public ResponseEntity<?>getAllTeam(){
        try{
            return new ResponseEntity<>(teamService.getAllTeams(),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try after some time",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("task/team/getallteammembers/{teamName}")
    public ResponseEntity<?>getAllTeamMembersBasedOnTeamName(@PathVariable String teamName){
        try{
            return new ResponseEntity<>(teamService.getAllTeamMembers(teamName),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try again after some time ",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("task/team/getallteamtask/{teamName}")
    public ResponseEntity<?>getAllTaskBasedOnTeamName(@PathVariable String teamName){
        try{
            return new ResponseEntity<>(teamService.getAllTeamTasks(teamName),HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>("try again after some time",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




}

