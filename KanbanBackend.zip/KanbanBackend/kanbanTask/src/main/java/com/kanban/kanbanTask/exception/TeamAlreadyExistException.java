package com.kanban.kanbanTask.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code= HttpStatus.CONFLICT, reason="Team already exits")
public class TeamAlreadyExistException extends Exception {
}
