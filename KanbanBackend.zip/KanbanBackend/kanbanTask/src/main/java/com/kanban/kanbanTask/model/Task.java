package com.kanban.kanbanTask.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.*;
import java.time.LocalDate;


@Document(collection = "tasks")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Task {

    @Transient
    public static final String SEQUENCE_NAME = "tasks_sequence";

    @Id
    private long taskId;
    private String taskTitle;
    private String taskDescription;
    private LocalDate taskDeadLine;
    @ManyToMany
    @JoinColumn(name = "task_assignee_email")
    private User taskAssignee;
    private String taskStatus;

}




