package com.kanban.kanbanTask.proxy;

import com.kanban.kanbanTask.model.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="authentication-service", url="localhost:8085")
public interface UserProxy {
    @PostMapping("/api/v2/register")
    public ResponseEntity<?> addingUserData(@RequestBody User user);

    @PutMapping("/api/v2/update/{emailId}")
    public ResponseEntity<?>updateUser(@PathVariable String emailId, @RequestBody User user);
}



















































































