package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.TaskNotExistException;
import com.kanban.kanbanTask.model.DatabseSequence;
import com.kanban.kanbanTask.model.Task;
import com.kanban.kanbanTask.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Service
public class TaskServiceImpl implements TaskService{
    private TaskRepository taskRepository;

    private MongoOperations mongoOperations;
    @Autowired
    public TaskServiceImpl(TaskRepository taskRepository, MongoOperations mongoOperations) {
        this.taskRepository = taskRepository;
        this.mongoOperations = mongoOperations;
    }
    long cnt=1;
    @Override
    public Task addTask(Task task) {
        task.setTaskId(generateSequence(Task.SEQUENCE_NAME));
        return taskRepository.save(task);
    }

    @Override
    public Task updateTask(Task task) throws TaskNotExistException {
        Task getTask= taskRepository.findByTaskId(task.getTaskId());

        if(getTask!=null){
            getTask.setTaskId(generateSequence(Task.SEQUENCE_NAME));
            getTask.setTaskTitle(task.getTaskTitle());
            getTask.setTaskDescription(task.getTaskDescription());
            getTask.setTaskStatus(task.getTaskStatus());
            getTask.setTaskDeadLine(task.getTaskDeadLine());
            getTask.setTaskAssignee(task.getTaskAssignee());
            taskRepository.save(getTask);
            taskRepository.deleteByTaskId(task.getTaskId());
            return getTask;
        }
        else {
            throw new TaskNotExistException();
        }
    }

    @Override
    public List<Task> getAllTasks(String email) {
        return taskRepository.findByTaskAssignee_Email(email);
    }

    @Override
    public boolean deleteTask(long taskId) throws TaskNotExistException {
        boolean result=false;
        if(taskRepository.findByTaskId(taskId)==null){
            throw new TaskNotExistException();
        }
        else{
            taskRepository.deleteByTaskId(taskId);
            result=true;
        }
        return result;
    }

    @Override
    public String deadlineAlert(LocalDate taskDeadline) {
        LocalDate today = LocalDate.now();
        int period= Period.between(today, taskDeadline).getDays();
        if (period < 10){
            return "red";
        }
        else if(period < 20 && period>=10){
            return "blue";
        }
        else if(period < 30 && period>=20){
            return "green";
        }
        else{
            return "yellow";
        }
    }

    @Override
    public Task searchTask(String taskTitle) {
        return taskRepository.findByTaskTitle(taskTitle);
    }

    @Override
    public Task findByTaskTitleAndTaskAssignee(String taskTitle, String taskAssignee)throws TaskNotExistException {
        return taskRepository.findByTaskTitleAndTaskAssignee_Email(taskTitle,taskAssignee);
    }

    public long generateSequence(String seqName) {
        DatabseSequence counter = mongoOperations.findAndModify(query(where("_id").is(seqName)),
                new Update().inc("seq",1), options().returnNew(true).upsert(true),
                DatabseSequence.class);
        return !Objects.isNull(counter) ? counter.getSeq() : 1;
    }
}



































