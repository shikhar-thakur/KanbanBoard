package com.kanban.kanbanTask.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;

@Document
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Team {
    @Id
    private String teamName;
    private List<User> teamMembers;
    private List<Task>teamTasks;
}
