package com.kanban.kanbanTask.service;

import com.kanban.kanbanTask.exception.TaskNotExistException;
import com.kanban.kanbanTask.model.Task;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface TaskService {
    Task addTask(Task task);
    Task updateTask(Task task) throws TaskNotExistException;
    boolean deleteTask(long taskId) throws TaskNotExistException;
    String deadlineAlert(LocalDate taskDeadline);
    Task searchTask(String taskTitle);
    List<Task> getAllTasks(String email);
    Task findByTaskTitleAndTaskAssignee(String taskTitle, String taskAssignee) throws TaskNotExistException;
}




















































































// DEVELOPED By Group 2(Wave-16)- KANBAN-BOARD APPLICATION [AMAN MASIH, SHEKHAR LOBO,SAI SANJANA BHUPATHIRAJU]