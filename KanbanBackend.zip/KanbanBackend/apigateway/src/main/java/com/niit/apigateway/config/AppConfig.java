package com.niit.apigateway.config;
import com.niit.apigateway.filter.JwtFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public RouteLocator myRoute(RouteLocatorBuilder routeLocatorBuilder) {


        return routeLocatorBuilder.routes()
                .route(p -> p.path("/api/**").uri("lb://kanban-task-service"))
                .route(p -> p.path("/api/v2/**").uri("lb://authentication-service")
                )
                .build();

    }
    @Bean
    FilterRegistrationBean jwtFilter(){
        FilterRegistrationBean filterRegistrationBean=new FilterRegistrationBean<>();
        filterRegistrationBean.setFilter(new JwtFilter());
        filterRegistrationBean.addUrlPatterns("/api/task/**");
        return filterRegistrationBean;
    }

}

